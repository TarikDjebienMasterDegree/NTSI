Compte rendu du tp not� de NTSI.

Ce qui fonctionne :

- page Acceuil
- page Login
- page Success
- page Consultation du compte

Ce qui ne fonctionne pas :
- page Effectuer un �change
- I18N sur la page d'acceuil

Ce qui n'a pas �t� fait :
- page administration

Cordialement,

Djebien Tarik