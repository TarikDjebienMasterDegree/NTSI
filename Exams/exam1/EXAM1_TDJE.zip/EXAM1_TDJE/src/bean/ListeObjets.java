package bean;

import java.util.List;

public class ListeObjets {
	
	private List<Objet> listeObjets;

	public List<Objet> getListeObjets() {
		return listeObjets;
	}

	public void setListeObjets(List<Objet> listeObjets) {
		this.listeObjets = listeObjets;
	}
	

}
