package bean;

import java.util.ArrayList;

public class Catalogue {
	
	private ArrayList<Livre> listeLivre;

	public ArrayList<Livre> getListeLivre() {
		return listeLivre;
	}

	public void setListeLivre(ArrayList<Livre> listeLivre) {
		this.listeLivre = listeLivre;
	}

}
