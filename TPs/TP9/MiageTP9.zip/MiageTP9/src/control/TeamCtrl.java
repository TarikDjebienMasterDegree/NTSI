package control;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import model.dao.TeamDao;
import model.dto.Team;

public class TeamCtrl {
	
	private TeamDao tDao = new TeamDao();
	private DataModel teams;
	private Team newTeam = new Team();
	private Team editTeam;
	
	public Team getEditTeam() {
		return editTeam;
	}
	
	public Team getNewTeam() {
		return newTeam;
	}

	public DataModel getTeams() {
		if(teams == null) {
			teams = new ListDataModel();
			teams.setWrappedData(tDao.selectAll());
		}
		return teams;
	}
	
	public String createTeam() {
		tDao.insert(newTeam);
		newTeam = new Team();
		teams.setWrappedData(tDao.selectAll());
		return "list";
	}
	
	public String deleteTeam() {
		Team t = (Team) teams.getRowData();
		tDao.delete(t);
		teams.setWrappedData(tDao.selectAll());
		return null;
	}
	
	public String editerTeamName() {
		editTeam = (Team) teams.getRowData();
		return "editTeamName";
	}
	
	public String updateTeam() {
		tDao.update(editTeam);
		teams.setWrappedData(tDao.selectAll());
		return "update";
	}

}
