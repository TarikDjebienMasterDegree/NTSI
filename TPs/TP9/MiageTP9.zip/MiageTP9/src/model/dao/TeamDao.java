package model.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import model.dto.Team;

public class TeamDao {
	
	private static final String JPA_UNIT_NAME = "miageTP9";
	
	private EntityManager entityManager;
	
	protected EntityManager getEntityManager(){
		if(entityManager == null){
			entityManager = Persistence.createEntityManagerFactory(JPA_UNIT_NAME).createEntityManager();
		}
		return entityManager;
	}
	
	public List<Team> selectAll() {
		@SuppressWarnings("unchecked")
		List<Team> teams = getEntityManager().createQuery("select t from Team t").getResultList();
		return teams;
	}
	
	public Team insert(Team t) {
		getEntityManager().getTransaction().begin();
		getEntityManager().persist(t);
		getEntityManager().getTransaction().commit();
		return t;
	}
	
	public void delete(Team t) {
		getEntityManager().getTransaction().begin();
		t = getEntityManager().merge(t);
		getEntityManager().remove(t);
		getEntityManager().getTransaction().commit();
	}
	
	public Team update(Team t) {
		getEntityManager().getTransaction().begin();
		t = getEntityManager().merge(t);
		getEntityManager().getTransaction().commit();
		return t;
	}

}
