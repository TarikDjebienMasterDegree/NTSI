package model.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Game implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Temporal(TemporalType.DATE)
	private Date gameDate;
	
	@ManyToOne
	@JoinColumn(name = "HOME_TEAM_ID")
	private Team homeTeam = new Team();
	
	@ManyToOne
	@JoinColumn(name = "AWAY_TEAM_ID")
	private Team awayTeam = new Team();
	
	@ManyToOne
	@JoinColumn(name = "MVP_ID")
	private Player mostValuablePlayer = new Player();

	private int homeTeamScore;
	
	private int awayTeamScore;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the gameDate
	 */
	public Date getGameDate() {
		return gameDate;
	}

	/**
	 * @param gameDate the gameDate to set
	 */
	public void setGameDate(Date gameDate) {
		this.gameDate = gameDate;
	}

	/**
	 * @return the homeTeam
	 */
	public Team getHomeTeam() {
		return homeTeam;
	}

	/**
	 * @param homeTeam the homeTeam to set
	 */
	public void setHomeTeam(Team homeTeam) {
		this.homeTeam = homeTeam;
	}

	/**
	 * @return the awayTeam
	 */
	public Team getAwayTeam() {
		return awayTeam;
	}

	/**
	 * @param awayTeam the awayTeam to set
	 */
	public void setAwayTeam(Team awayTeam) {
		this.awayTeam = awayTeam;
	}

	/**
	 * @return the mostValuablePlayer
	 */
	public Player getMostValuablePlayer() {
		return mostValuablePlayer;
	}

	/**
	 * @param mostValuablePlayer the mostValuablePlayer to set
	 */
	public void setMostValuablePlayer(Player mostValuablePlayer) {
		this.mostValuablePlayer = mostValuablePlayer;
	}

	/**
	 * @return the homeTeamScore
	 */
	public int getHomeTeamScore() {
		return homeTeamScore;
	}

	/**
	 * @param homeTeamScore the homeTeamScore to set
	 */
	public void setHomeTeamScore(int homeTeamScore) {
		this.homeTeamScore = homeTeamScore;
	}

	/**
	 * @return the awayTeamScore
	 */
	public int getAwayTeamScore() {
		return awayTeamScore;
	}

	/**
	 * @param awayTeamScore the awayTeamScore to set
	 */
	public void setAwayTeamScore(int awayTeamScore) {
		this.awayTeamScore = awayTeamScore;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((awayTeam == null) ? 0 : awayTeam.hashCode());
		result = prime * result + awayTeamScore;
		result = prime * result
				+ ((gameDate == null) ? 0 : gameDate.hashCode());
		result = prime * result
				+ ((homeTeam == null) ? 0 : homeTeam.hashCode());
		result = prime * result + homeTeamScore;
		result = prime * result + id;
		result = prime
				* result
				+ ((mostValuablePlayer == null) ? 0 : mostValuablePlayer
						.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Game other = (Game) obj;
		if (awayTeam == null) {
			if (other.awayTeam != null)
				return false;
		} else if (!awayTeam.equals(other.awayTeam))
			return false;
		if (awayTeamScore != other.awayTeamScore)
			return false;
		if (gameDate == null) {
			if (other.gameDate != null)
				return false;
		} else if (!gameDate.equals(other.gameDate))
			return false;
		if (homeTeam == null) {
			if (other.homeTeam != null)
				return false;
		} else if (!homeTeam.equals(other.homeTeam))
			return false;
		if (homeTeamScore != other.homeTeamScore)
			return false;
		if (id != other.id)
			return false;
		if (mostValuablePlayer == null) {
			if (other.mostValuablePlayer != null)
				return false;
		} else if (!mostValuablePlayer.equals(other.mostValuablePlayer))
			return false;
		return true;
	}

}
