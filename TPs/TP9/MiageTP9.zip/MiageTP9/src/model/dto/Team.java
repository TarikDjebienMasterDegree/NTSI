package model.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Team implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TEAM_ID")
	private int id;
	private String name;
	
	@OneToMany(mappedBy = "team")
	private Set<Player> players = new HashSet<Player>();
	
	@OneToMany(mappedBy = "homeTeam")
	@MapKey(name = "gameDate")
	private Map<Date, Game> homeGames = new HashMap<Date, Game>();
	
	@OneToMany(mappedBy = "awayTeam")
	@MapKey(name = "gameDate")
	private Map<Date, Game> awayGames = new HashMap<Date, Game>();
	
	@OneToOne
	private Coach coach = new Coach();

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the players
	 */
	public Set<Player> getPlayers() {
		return players;
	}

	/**
	 * @param players the players to set
	 */
	public void setPlayers(Set<Player> players) {
		this.players = players;
	}

	/**
	 * @return the homeGames
	 */
	public Map<Date, Game> getHomeGames() {
		return homeGames;
	}

	/**
	 * @param homeGames the homeGames to set
	 */
	public void setHomeGames(Map<Date, Game> homeGames) {
		this.homeGames = homeGames;
	}

	/**
	 * @return the awayGames
	 */
	public Map<Date, Game> getAwayGames() {
		return awayGames;
	}

	/**
	 * @param awayGames the awayGames to set
	 */
	public void setAwayGames(Map<Date, Game> awayGames) {
		this.awayGames = awayGames;
	}

	/**
	 * @return the coach
	 */
	public Coach getCoach() {
		return coach;
	}

	/**
	 * @param coach the coach to set
	 */
	public void setCoach(Coach coach) {
		this.coach = coach;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((awayGames == null) ? 0 : awayGames.hashCode());
		result = prime * result + ((coach == null) ? 0 : coach.hashCode());
		result = prime * result
				+ ((homeGames == null) ? 0 : homeGames.hashCode());
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((players == null) ? 0 : players.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Team other = (Team) obj;
		if (awayGames == null) {
			if (other.awayGames != null)
				return false;
		} else if (!awayGames.equals(other.awayGames))
			return false;
		if (coach == null) {
			if (other.coach != null)
				return false;
		} else if (!coach.equals(other.coach))
			return false;
		if (homeGames == null) {
			if (other.homeGames != null)
				return false;
		} else if (!homeGames.equals(other.homeGames))
			return false;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (players == null) {
			if (other.players != null)
				return false;
		} else if (!players.equals(other.players))
			return false;
		return true;
	}
	
}
